// backend/routes/auth.js
import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pool from '../db.js';
import dotenv from 'dotenv';
dotenv.config();

const SECRET = process.env.JWT_SECRET || 'dev-secret';
const router = express.Router();

async function findUserByUsername(username) {
  // 1) Esquema estándar: usuarios(username, password_hash, role)
  try {
    const { rows } = await pool.query(
      `SELECT id, username, role, password_hash
       FROM usuarios
       WHERE username = $1
       LIMIT 1`,
      [username]
    );
    if (rows.length) return rows[0];
  } catch (_) { /* ignore and try fallback */ }

  // 2) Variante con columnas en español: usuarios(usuario, contrasena_hash/ password)
  try {
    const { rows } = await pool.query(
      `SELECT
         id,
         usuario  AS username,
         COALESCE(rol, 'user') AS role,
         -- prioriza contrasena_hash; si no existe, intenta password_hash; si no, password
         clave_hash        AS password_hash
       FROM usuarios
       WHERE usuario = $1
       LIMIT 1`,
      [username]
    );
    if (rows.length && rows[0].password_hash) return rows[0];
  } catch (_) { /* ignore */ }

  try {
    const { rows } = await pool.query(
      `SELECT
         id,
         usuario  AS username,
         COALESCE(rol, 'user') AS role,
         clave_hash         AS password_hash
       FROM usuarios
       WHERE usuario = $1
       LIMIT 1`,
      [username]
    );
    if (rows.length && rows[0].password_hash) return rows[0];
  } catch (_) { /* ignore */ }

  try {
    const { rows } = await pool.query(
      `SELECT
         id,
         usuario  AS username,
         COALESCE(rol, 'user') AS role,
         clave_hash               AS password_hash
       FROM usuarios
       WHERE usuario = $1
       LIMIT 1`,
      [username]
    );
    if (rows.length && rows[0].password_hash) return rows[0];
  } catch (_) { /* ignore */ }

  return null;
}

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ error: 'Faltan credenciales' });
    }

    const u = await findUserByUsername(username);
    if (!u) return res.status(401).json({ error: 'Usuario o clave inválidos' });

    if (!u.password_hash || typeof u.password_hash !== 'string') {
      return res.status(500).json({ error: 'password_hash_missing' });
    }

    const ok = await bcrypt.compare(password, u.password_hash);
    if (!ok) return res.status(401).json({ error: 'Usuario o clave inválidos' });

    const token = jwt.sign(
      { id: u.id, username: u.username, role: u.role || 'user' },
      SECRET,
      { expiresIn: '1d' }
    );

    return res.json({ token, role: u.role || 'user', username: u.username });
  } catch (e) {
    console.error('POST /auth/login', e);
    return res.status(500).json({ error: 'Error de login' });
  }
});

export default router;
