// backend/routes/brackets.js
import { Router } from 'express';
import pool from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

/* ------------------------------------------------------------------
   Helpers
------------------------------------------------------------------- */

// crea partidos para un bracket a partir de un orden de equipos.
// soporta 3–11 equipos con byes (como veníamos).
async function createBracketFromTemplate({ client, disciplina_id, nombre, equipoIds }) {
  // 1) crear bracket
  const { rows: br } = await client.query(
    `INSERT INTO public.brackets (disciplina_id, nombre, creado_en)
     VALUES ($1,$2,NOW()) RETURNING id`,
    [disciplina_id, nombre]
  );
  const bracketId = br[0].id;

  // 2) armar estructura (round/orden/next_match_id) según cantidad
  //    Nota: mantenemos el mismo esquema que ya te funcionaba.
  const n = equipoIds.length;

  // util: crea partido y devuelve id
  const mk = async (round, orden, equipo1_id, equipo2_id, next_match_id = null) => {
    const { rows } = await client.query(
      `INSERT INTO public.partidos
         (bracket_id, disciplina_id, round, orden, equipo1_id, equipo2_id, estado, next_match_id)
       VALUES ($1,$2,$3,$4,$5,$6,'pendiente',$7)
       RETURNING id`,
      [bracketId, disciplina_id, round, orden, equipo1_id || null, equipo2_id || null, next_match_id]
    );
    return rows[0].id;
  };

  // Plantillas simples:
  // Producimos la lista de partidos iniciales, y después vamos “linkeando” con next_match_id.
  // Casos pequeños (3–11) con byes:
  const ids = equipoIds.slice(); // ya vienen en orden elegido
  const partidos = []; // guardamos {round,orden,id}
  const link = [];     // para armar next_match_id

  // función helper que crea una ronda a partir de pares (a,b) (pueden venir null = bye)
  const makeRound = async (round, pares) => {
    const current = [];
    for (let i = 0; i < pares.length; i++) {
      const [a, b] = pares[i];
      const idp = await mk(round, i + 1, a, b, null);
      current.push({ id: idp, round, orden: i + 1 });
    }
    partidos.push(...current);
    return current;
  };

  // arma pareos de la primera ronda con byes según n
  function firstRoundPairs(list) {
    // distribuciones típicas por cantidad (mantenemos tu criterio)
    // n=3 -> (1 vs 2), (3 bye) => R1: [ (1,2) ], R2: final (ganador vs 3)
    // n=4 -> (1 vs 2), (3 vs 4)
    // n=5 -> (1 vs 2), (3 vs 4), (5 bye). Semis: (ganador(1-2) vs 5), (ganador(3-4) vs bye?)
    //       en tu versión: el ganador 1–2 pasa directo a final y el libre de 1ª ronda juega semi con ganador 3–4.
    //       lo respetamos igual.
    // Para no hacer el bloque enorme acá, tratamos 6–11 como:
    // completar a potencia de 2 con byes al final, y parear en orden.
    const pairs = [];
    if (list.length === 3) {
      pairs.push([list[0], list[1]]);
      // list[2] espera a la final (bye)
      return { pairs, byes: [list[2]] };
    }
    if (list.length === 4) {
      pairs.push([list[0], list[1]], [list[2], list[3]]);
      return { pairs, byes: [] };
    }
    if (list.length === 5) {
      // tu lógica “exacta”: R1: (1–2), (3–4), libre 5.
      pairs.push([list[0], list[1]], [list[2], list[3]]);
      return { pairs, byes: [list[4]] };
    }
    // ≥6: completar a potencia de 2
    const pow2 = 1 << Math.ceil(Math.log2(list.length));
    const byesN = pow2 - list.length;
    const all = list.concat(Array(byesN).fill(null));
    for (let i = 0; i < all.length; i += 2) {
      pairs.push([all[i], all[i + 1]]);
    }
    return { pairs, byes: [] };
  }

  // 1ª ronda
  const { pairs, byes } = firstRoundPairs(ids);
  const r1 = await makeRound(1, pairs);

  // funcion que a partir de una ronda crea la siguiente,
  // conectando next_match_id
  const chainNext = async (prevRound, roundNum, extraBye = null, specialFive = false) => {
    const nextPairs = [];
    // casos especiales:
    if (specialFive) {
      // n=5: ganador(1–2) -> FINAL directamente;
      //      semifinal: (ganador(3–4) vs libre 5)
      // prevRound tiene 2 partidos: prevRound[0] = (1–2), prevRound[1] = (3–4)
      // Creamos 2 partidos: Semi y Final
      // Primero creamos Final vacío para poder linkear semi y el ganador 1–2.
      const finalId = await mk(3, 1, null, null, null); // R3 final
      // Semi R2: (ganador(3–4) vs libre 5)
      const semiId = await mk(2, 1, null, extraBye, finalId);

      // Link: partido (3–4) -> semi; partido (1–2) -> final
      await client.query(`UPDATE public.partidos SET next_match_id=$1 WHERE id=$2`, [finalId, prevRound[0].id]);
      await client.query(`UPDATE public.partidos SET next_match_id=$1 WHERE id=$2`, [semiId, prevRound[1].id]);

      return { semiId, finalId };
    }

    // general: emparejar de a dos
    for (let i = 0; i < prevRound.length; i += 2) {
      const left = prevRound[i];
      const right = prevRound[i + 1] || null;
      // creamos el partido de la ronda siguiente
      const nextId = await mk(roundNum, nextPairs.length + 1, null, null, null);
      // linkeamos
      if (left)  await client.query(`UPDATE public.partidos SET next_match_id=$1 WHERE id=$2`, [nextId, left.id]);
      if (right) await client.query(`UPDATE public.partidos SET next_match_id=$1 WHERE id=$2`, [nextId, right.id]);
      nextPairs.push({ id: nextId, round: roundNum, orden: nextPairs.length + 1 });
    }
    return nextPairs;
  };

  if (n === 3) {
    // final directa: ganador(1–2) vs bye(list[2])
    const finalId = await mk(2, 1, null, byes[0], null);
    await client.query(`UPDATE public.partidos SET next_match_id=$1 WHERE id=$2`, [finalId, r1[0].id]);
  } else if (n === 5) {
    await chainNext(r1, 0, byes[0], true); // specialFive=true
  } else {
    // build until final
    let prev = r1;
    let round = 2;
    while (prev.length > 1) {
      prev = await chainNext(prev, round++);
    }
  }

  return bracketId;
}

/* ------------------------------------------------------------------
   RUTAS
------------------------------------------------------------------- */

// Generar llaves
router.post('/generate', requireAuth, async (req, res) => {
  const { disciplina_id, nombre, equipo_ids_en_orden } = req.body || {};
  if (!disciplina_id || !Array.isArray(equipo_ids_en_orden) || equipo_ids_en_orden.length < 3) {
    return res.status(400).json({ error: 'Datos inválidos' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // validar que todos estén asignados a la disciplina
    const { rows: asign } = await client.query(
      `SELECT equipo_id FROM public.equipos_disciplinas
        WHERE disciplina_id=$1 AND equipo_id = ANY($2::int[])`,
      [disciplina_id, equipo_ids_en_orden]
    );
    const okIds = new Set(asign.map(r => r.equipo_id));
    const notAssigned = equipo_ids_en_orden.filter(id => !okIds.has(id));
    if (notAssigned.length) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Equipos no asignados a la disciplina', detalle: { notAssigned } });
    }

    const bracket_id = await createBracketFromTemplate({
      client,
      disciplina_id,
      nombre: nombre || 'Llave',
      equipoIds: equipo_ids_en_orden
    });

    await client.query('COMMIT');
    res.json({ bracket_id });

  } catch (e) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error('POST /brackets/generate', e);
    res.status(500).json({ error: 'Error generando bracket' });
  } finally {
    client.release();
  }
});

// Programar una ronda (igual que antes)
router.post('/schedule', requireAuth, async (req, res) => {
  const { bracket_id, round, start_datetime, interval_minutes } = req.body || {};
  if (!bracket_id || !round || !start_datetime || !interval_minutes) {
    return res.status(400).json({ error: 'Datos inválidos' });
  }
  try {
    const { rows } = await pool.query(
      `SELECT id FROM public.partidos
        WHERE bracket_id=$1 AND round=$2
        ORDER BY orden`,
      [bracket_id, round]
    );
    let t = new Date(start_datetime);
    for (const r of rows) {
      await pool.query(
        `UPDATE public.partidos SET fecha=$1 WHERE id=$2`,
        [t.toISOString(), r.id]
      );
      t = new Date(t.getTime() + interval_minutes * 60000);
    }
    res.json({ ok: true, count: rows.length });
  } catch (e) {
    console.error('POST /brackets/schedule', e);
    res.status(500).json({ error: 'Error programando ronda' });
  }
});

// Rondas de un bracket
router.get('/:id/rounds', requireAuth, async (req, res) => {
  const id = Number(req.params.id || 0);
  if (!id) return res.json({});
  try {
    const { rows } = await pool.query(
      `SELECT p.id, p.round, p.orden, p.fecha, p.estado,
              p.equipo1_id, p.equipo2_id,
              r.puntaje_equipo1 AS s1, r.puntaje_equipo2 AS s2,
              p.parcial_equipo1, p.parcial_equipo2,
              e1.nombre AS n1, e2.nombre AS n2,
              p.next_match_id
       FROM public.partidos p
       LEFT JOIN public.resultados r ON r.partido_id = p.id
       LEFT JOIN public.equipos e1 ON e1.id = p.equipo1_id
       LEFT JOIN public.equipos e2 ON e2.id = p.equipo2_id
       WHERE p.bracket_id = $1
       ORDER BY p.round, p.orden`,
      [id]
    );
    const out = {};
    for (const m of rows) {
      if (!out[m.round]) out[m.round] = [];
      out[m.round].push(m);
    }
    res.json(out);
  } catch (e) {
    console.error('GET /brackets/:id/rounds', e);
    res.status(500).json({ error: 'Error leyendo rounds' });
  }
});

// Último bracket por disciplina (para el visor)
router.get('/byDisciplina/:disciplinaId', requireAuth, async (req, res) => {
  const disciplinaId = Number(req.params.disciplinaId || 0);
  if (!disciplinaId) return res.json({ bracket_id: null, rounds: {} });
  try {
    const { rows: br } = await pool.query(
      `SELECT id FROM public.brackets
       WHERE disciplina_id=$1
       ORDER BY id DESC
       LIMIT 1`,
      [disciplinaId]
    );
    if (!br.length) return res.json({ bracket_id: null, rounds: {} });

    const bracketId = br[0].id;
    const { rows } = await pool.query(
      `SELECT p.id, p.round, p.orden, p.fecha, p.estado,
              p.equipo1_id, p.equipo2_id,
              r.puntaje_equipo1 AS s1, r.puntaje_equipo2 AS s2,
              p.parcial_equipo1, p.parcial_equipo2,
              e1.nombre AS n1, e2.nombre AS n2,
              p.next_match_id
       FROM public.partidos p
       LEFT JOIN public.resultados r ON r.partido_id = p.id
       LEFT JOIN public.equipos e1 ON e1.id = p.equipo1_id
       LEFT JOIN public.equipos e2 ON e2.id = p.equipo2_id
       WHERE p.bracket_id = $1
       ORDER BY p.round, p.orden`,
      [bracketId]
    );
    const rounds = {};
    for (const m of rows) {
      if (!rounds[m.round]) rounds[m.round] = [];
      rounds[m.round].push(m);
    }
    res.json({ bracket_id: bracketId, rounds });
  } catch (e) {
    console.error('GET /brackets/byDisciplina/:id', e);
    res.status(500).json({ error: 'Error buscando bracket por disciplina' });
  }
});

export default router;
