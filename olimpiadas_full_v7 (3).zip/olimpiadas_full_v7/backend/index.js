// backend/index.js
import express from 'express';
import http from 'http';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { Server as IOServer } from 'socket.io';
import dotenv from 'dotenv';

import pool from './db.js';
import authRouter from './routes/auth.js';
import bracketsRouter from './routes/brackets.js';
import { requireAuth, requireRole } from './middleware/auth.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT   = process.env.PORT || 3000;
const ORIGIN = process.env.CORS_ORIGIN || '*';

const app = express();
const server = http.createServer(app);
const io = new IOServer(server, {
  cors: { origin: ORIGIN, methods: ['GET','POST','PUT','DELETE','OPTIONS'] },
  path: '/socket.io/'
});

// dejar io disponible en handlers
app.set('io', io);

// middlewares
app.use(cors({ origin: ORIGIN }));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// servir frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// rutas base
app.use('/auth', authRouter);
app.use('/api/auth', authRouter);
app.use('/api/brackets', bracketsRouter);

// ===== helpers socket =====
function emitPartidoUpdated(bracket_id){
  try { io.emit('partido_updated', { bracket_id }); } catch {}
}
function emitMedalleroChanged(){
  try { io.emit('medallero_changed'); } catch {}
}

// ====================== Endpoints usados por admin.html ======================

// Disciplinas
app.get('/api/disciplinas', requireAuth, async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, nombre FROM disciplinas ORDER BY nombre');
    res.json(rows);
  } catch (e) {
    console.error('GET /api/disciplinas', e);
    res.status(500).json({ error: 'Error cargando disciplinas' });
  }
});

// Equipos (todos o por disciplina)
app.get('/api/equipos', requireAuth, async (req, res) => {
  try {
    const did = Number(req.query.disciplina_id || 0);
    if (did) {
      const { rows } = await pool.query(
        `SELECT e.id, e.nombre
           FROM equipos e
           JOIN equipos_disciplinas ed ON ed.equipo_id = e.id
          WHERE ed.disciplina_id = $1
          ORDER BY e.nombre`,
        [did]
      );
      return res.json(rows);
    }
    const { rows } = await pool.query('SELECT id, nombre FROM equipos ORDER BY nombre');
    res.json(rows);
  } catch (e) {
    console.error('GET /api/equipos', e);
    res.status(500).json({ error: 'Error cargando equipos' });
  }
});

// IDs asignados a una disciplina
app.get('/api/asignados', requireAuth, async (req, res) => {
  try {
    const did = Number(req.query.disciplina_id || 0);
    if (!did) return res.json([]);
    const { rows } = await pool.query(
      'SELECT equipo_id FROM equipos_disciplinas WHERE disciplina_id=$1 ORDER BY equipo_id',
      [did]
    );
    res.json(rows); // [{equipo_id:...}]
  } catch (e) {
    console.error('GET /api/asignados', e);
    res.status(500).json({ error: 'Error cargando asignaciones' });
  }
});

// Guardar asignaciones (reemplaza todas)
app.post('/api/asignar_equipos', requireAuth, async (req, res) => {
  const { disciplina_id, equipo_ids } = req.body || {};
  if (!disciplina_id || !Array.isArray(equipo_ids)) {
    return res.status(400).json({ error: 'Datos inválidos' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM equipos_disciplinas WHERE disciplina_id=$1', [disciplina_id]);
    if (equipo_ids.length) {
      const values = equipo_ids.map((_, i) => `($1,$${i+2})`).join(',');
      await client.query(
        `INSERT INTO equipos_disciplinas (disciplina_id, equipo_id) VALUES ${values}`,
        [disciplina_id, ...equipo_ids]
      );
    }
    await client.query('COMMIT');
    res.json({ ok:true });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /api/asignar_equipos', e);
    res.status(500).json({ error: 'Error guardando asignaciones' });
  } finally {
    client.release();
  }
});

// ====== Parcial tiempo regular
app.post('/api/partidos/:id/parcial', requireAuth, async (req, res) => {
  const id = Number(req.params.id);
  const { parcial_equipo1 = 0, parcial_equipo2 = 0 } = req.body || {};
  try {
    const { rows } = await pool.query(
      `UPDATE public.partidos
          SET parcial_equipo1=$1,
              parcial_equipo2=$2,
              parcial_actualizado_en=NOW()
        WHERE id=$3
        RETURNING bracket_id`,
      [parcial_equipo1, parcial_equipo2, id]
    );
    const bid = rows[0]?.bracket_id ?? null;
    if (bid) emitPartidoUpdated(bid);
    res.json({ ok:true });
  } catch (e) {
    console.error('POST /api/partidos/:id/parcial', e);
    res.status(500).json({ error: 'Error guardando parcial' });
  }
});

// ====== PENALIDADES ======
// Parcial de penales
app.post('/api/partidos/:id/penales/parcial', requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { p1, p2 } = req.body || {};
    const { rows } = await pool.query(
      `UPDATE public.partidos
          SET pen_parcial1=$1,
              pen_parcial2=$2,
              estado='penales'
        WHERE id=$3
        RETURNING bracket_id`,
      [p1 ?? null, p2 ?? null, id]
    );
    const bid = rows[0]?.bracket_id ?? null;
    if (bid) emitPartidoUpdated(bid);
    res.json({ ok:true });
  } catch (e) {
    console.error('POST /api/partidos/:id/penales/parcial', e);
    res.status(500).json({ error: 'Error guardando penales (parcial)' });
  }
});

// Final de penales (define ganador y avanza)
app.post('/api/partidos/:id/penales/final', requireAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    const id = Number(req.params.id);
    const { p1, p2 } = req.body || {};

    // Traer el partido
    const { rows: pr } = await client.query(`
      SELECT p.*
        FROM public.partidos p
       WHERE p.id = $1
       LIMIT 1
    `, [id]);
    if (!pr.length) return res.status(404).json({ error: 'Partido no encontrado' });
    const P = pr[0];

    if (!P.equipo1_id || !P.equipo2_id) {
      return res.status(400).json({ error: 'Partido incompleto' });
    }

    const pen1 = Number(p1 ?? 0);
    const pen2 = Number(p2 ?? 0);
    if (pen1 === pen2) {
      return res.status(400).json({ error: 'Los penales no pueden terminar empatados' });
    }

    const ganadorId  = pen1 > pen2 ? P.equipo1_id : P.equipo2_id;
    const perdedorId = ganadorId === P.equipo1_id ? P.equipo2_id : P.equipo1_id;

    await client.query('BEGIN');

    // Upsert manual en resultados
    const upd = await client.query(`
      UPDATE public.resultados
         SET ganador_id = $4,
             penales_equipo1 = $5,
             penales_equipo2 = $6,
             definido_por_penales = true,
             puntaje_equipo1 = COALESCE(puntaje_equipo1, $2),
             puntaje_equipo2 = COALESCE(puntaje_equipo2, $3)
       WHERE partido_id = $1
    `, [ id, P.parcial_equipo1 ?? 0, P.parcial_equipo2 ?? 0, ganadorId, pen1, pen2 ]);

    if (upd.rowCount === 0) {
      await client.query(`
        INSERT INTO public.resultados
          (partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id,
           penales_equipo1, penales_equipo2, definido_por_penales)
        VALUES ($1,$2,$3,$4,$5,$6,true)
      `, [ id, P.parcial_equipo1 ?? 0, P.parcial_equipo2 ?? 0, ganadorId, pen1, pen2 ]);
    }

    // Cerrar partido
    await client.query(
      `UPDATE public.partidos SET estado='finalizado' WHERE id=$1`,
      [id]
    );

    // Avanzar a siguiente partido si corresponde
    if (P.next_match_id) {
      const col = (Number(P.next_match_side) === 2) ? 'equipo2_id' : 'equipo1_id';
      await client.query(
        `UPDATE public.partidos SET ${col}=$1 WHERE id=$2`,
        [ganadorId, P.next_match_id]
      );

      // Si ya están ambos, dejarlo 'pendiente'
      await client.query(`
        UPDATE public.partidos
           SET estado = CASE
                          WHEN equipo1_id IS NOT NULL AND equipo2_id IS NOT NULL THEN 'pendiente'
                          ELSE estado
                        END
         WHERE id = $1
      `, [P.next_match_id]);

    } else {
      // Era la FINAL real → medallero (campeón=3, subcampeón=1)
      const { rows: eqRows } = await client.query(`
        SELECT id, sucursal FROM public.equipos WHERE id = ANY($1::int[])
      `, [[ganadorId, perdedorId]]);
      const byId = new Map(eqRows.map(r => [r.id, r.sucursal]));
      const sucGan = byId.get(ganadorId)  || 'DESCONOCIDA';
      const sucSub = byId.get(perdedorId) || 'DESCONOCIDA';

      await client.query(`
        INSERT INTO public.medallero
          (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
        VALUES ($1, 3, $3, $4, $5)
        ON CONFLICT DO NOTHING
      `, [sucGan, 3, P.disciplina_id, P.bracket_id, id]);

      await client.query(`
        INSERT INTO public.medallero
          (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
        VALUES ($1, 1, $3, $4, $5)
        ON CONFLICT DO NOTHING
      `, [sucSub, 1, P.disciplina_id, P.bracket_id, id]);

      emitMedalleroChanged();
    }

    await client.query('COMMIT');
    emitPartidoUpdated(P.bracket_id);
    res.json({ ok: true });

  } catch (e) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error('POST /api/partidos/:id/penales/final', e);
    res.status(500).json({ error: 'Error guardando penales (final)' });
  } finally {
    client.release();
  }
});

// ====== FINAL TIEMPO REGULAR ======
/*app.post('/api/partidos/:id/final', requireAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    const partidoId = Number(req.params.id);
    const { puntaje_equipo1, puntaje_equipo2 } = req.body || {};

    // Traer el partido
    const { rows: pRows } = await client.query(`
      SELECT p.id, p.bracket_id, p.disciplina_id, p.round, p.orden,
             p.equipo1_id, p.equipo2_id,
             p.next_match_id, p.next_match_side
        FROM public.partidos p
       WHERE p.id = $1
       LIMIT 1
    `, [partidoId]);

    if (!pRows.length) return res.status(404).json({ error: 'Partido no encontrado' });
    const P = pRows[0];

    if (!P.equipo1_id || !P.equipo2_id) {
      return res.status(400).json({ error: 'Partido incompleto' });
    }

    const s1 = Number(puntaje_equipo1) || 0;
    const s2 = Number(puntaje_equipo2) || 0;
    if (s1 === s2) {
      return res.status(400).json({ error: 'El partido no puede terminar empatado' });
    }

    const ganadorId    = s1 > s2 ? P.equipo1_id : P.equipo2_id;
    const subcampeonId = s1 > s2 ? P.equipo2_id : P.equipo1_id;

    await client.query('BEGIN');

    // Upsert manual en resultados (tiempo regular) — si existe, actualiza
    const upd = await client.query(`
      UPDATE public.resultados
         SET puntaje_equipo1 = $2,
             puntaje_equipo2 = $3,
             ganador_id      = $4,
             penales_equipo1 = NULL,
             penales_equipo2 = NULL,
             definido_por_penales = false
       WHERE partido_id = $1
    `, [ partidoId, s1, s2, ganadorId ]);

    if (upd.rowCount === 0) {
      await client.query(`
        INSERT INTO public.resultados
          (partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id, definido_por_penales)
        VALUES ($1,$2,$3,$4,false)
      `, [ partidoId, s1, s2, ganadorId ]);
    }

    // Cerrar partido
    await client.query(`UPDATE public.partidos SET estado='finalizado' WHERE id=$1`, [partidoId]);

    const esFinal = (P.next_match_id === null);

    if (!esFinal) {
      // Avanzar ganador al siguiente partido (respeta next_match_side)
      const col = (Number(P.next_match_side) === 2) ? 'equipo2_id' : 'equipo1_id';
      await client.query(
        `UPDATE public.partidos SET ${col}=$1 WHERE id=$2`,
        [ganadorId, P.next_match_id]
      );

      // Si ya están ambos equipos, marcar pendiente
      await client.query(`
        UPDATE public.partidos
           SET estado = CASE
                          WHEN equipo1_id IS NOT NULL AND equipo2_id IS NOT NULL THEN 'pendiente'
                          ELSE estado
                        END
         WHERE id = $1
      `, [P.next_match_id]);

    } else {
      // FINAL real → medallero (3 y 1)
      const { rows: eqRows } = await client.query(`
        SELECT id, sucursal FROM public.equipos WHERE id = ANY($1::int[])
      `, [[ganadorId, subcampeonId]]);
      const byId = new Map(eqRows.map(r => [r.id, r.sucursal]));
      const sucGan = byId.get(ganadorId)    || 'DESCONOCIDA';
      const sucSub = byId.get(subcampeonId) || 'DESCONOCIDA';

      await client.query(`
        INSERT INTO public.medallero
          (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
        VALUES ($1, 3, $3, $4, $5)
        ON CONFLICT DO NOTHING
      `, [sucGan, 3, P.disciplina_id, P.bracket_id, partidoId]);

      await client.query(`
        INSERT INTO public.medallero
          (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
        VALUES ($1, 1, $3, $4, $5)
        ON CONFLICT DO NOTHING
      `, [sucSub, 1, P.disciplina_id, P.bracket_id, partidoId]);

      emitMedalleroChanged();
    }

    await client.query('COMMIT');
    emitPartidoUpdated(P.bracket_id);
    res.json({ ok: true, esFinal });

  } catch (err) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error('POST /api/partidos/:id/final error:', err);
    res.status(500).json({ error: 'Error guardando final' });
  } finally {
    client.release();
  }
});*/

// ====== FINAL TIEMPO REGULAR: permite empate → pasa a estado "penales"
app.post('/api/partidos/:id/final', requireAuth, async (req, res) => {
  const client = await pool.connect();
  try {
    const partidoId = Number(req.params.id);
    const { puntaje_equipo1, puntaje_equipo2 } = req.body || {};

    // Traer datos clave del partido
    const { rows: pRows } = await client.query(`
      SELECT p.id, p.bracket_id, p.disciplina_id, p.round, p.orden,
             p.equipo1_id, p.equipo2_id,
             p.next_match_id, p.next_match_side,
             p.estado
        FROM public.partidos p
       WHERE p.id = $1
       LIMIT 1
    `, [partidoId]);
    if (!pRows.length) return res.status(404).json({ error: 'Partido no encontrado' });

    const P  = pRows[0];
    if (!P.equipo1_id || !P.equipo2_id) {
      return res.status(400).json({ error: 'Partido incompleto' });
    }

    const s1 = Number(puntaje_equipo1) || 0;
    const s2 = Number(puntaje_equipo2) || 0;

    await client.query('BEGIN');

    // Si hay empate → guardamos marcador y pasamos a estado "penales"
    if (s1 === s2) {
      // Upsert resultados SIN ganador y SIN penales (todavía)
      const upd = await client.query(`
        UPDATE public.resultados
           SET puntaje_equipo1 = $2,
               puntaje_equipo2 = $3,
               ganador_id      = NULL,
               penales_equipo1 = NULL,
               penales_equipo2 = NULL,
               definido_por_penales = false
         WHERE partido_id = $1
      `, [ partidoId, s1, s2 ]);

      if (upd.rowCount === 0) {
        await client.query(`
          INSERT INTO public.resultados
            (partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id,
             penales_equipo1, penales_equipo2, definido_por_penales)
          VALUES ($1,$2,$3,NULL,NULL,NULL,false)
        `, [partidoId, s1, s2]);
      }

      // El partido queda “en penales”
      await client.query(`
        UPDATE public.partidos
           SET estado='penales'
         WHERE id=$1
      `, [partidoId]);

      await client.query('COMMIT');
      try { io.emit('partido_updated', { partido_id: partidoId, bracket_id: P.bracket_id }); } catch {}
      return res.json({ ok:true, requierePenales:true });
    }

    // Si NO hay empate → definimos ganador y avanzamos como antes
    const ganadorId    = s1 > s2 ? P.equipo1_id : P.equipo2_id;
    const subcampeonId = s1 > s2 ? P.equipo2_id : P.equipo1_id;

    // Upsert resultados con ganador (tiempo regular)
    const upd = await client.query(`
      UPDATE public.resultados
         SET puntaje_equipo1 = $2,
             puntaje_equipo2 = $3,
             ganador_id      = $4,
             penales_equipo1 = NULL,
             penales_equipo2 = NULL,
             definido_por_penales = false
       WHERE partido_id = $1
    `, [ partidoId, s1, s2, ganadorId ]);

    if (upd.rowCount === 0) {
      await client.query(`
        INSERT INTO public.resultados
          (partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id, definido_por_penales)
        VALUES ($1,$2,$3,$4,false)
      `, [ partidoId, s1, s2, ganadorId ]);
    }

    // Cerrar partido
    await client.query(`UPDATE public.partidos SET estado='finalizado' WHERE id=$1`, [partidoId]);

    const esFinal = (P.next_match_id === null);

    if (!esFinal) {
      // Avanza a siguiente partido
      const { rows: nr } = await client.query(
        `SELECT id, equipo1_id, equipo2_id FROM public.partidos WHERE id=$1`,
        [P.next_match_id]
      );
      const N = nr[0];

      if (!N.equipo1_id) {
        await client.query(`UPDATE public.partidos SET equipo1_id=$1 WHERE id=$2`, [ganadorId, P.next_match_id]);
      } else if (!N.equipo2_id) {
        await client.query(`UPDATE public.partidos SET equipo2_id=$1 WHERE id=$2`, [ganadorId, P.next_match_id]);
      }

      await client.query(`
        UPDATE public.partidos
           SET estado = CASE
                          WHEN equipo1_id IS NOT NULL AND equipo2_id IS NOT NULL THEN 'pendiente'
                          ELSE estado
                        END
         WHERE id = $1
      `, [P.next_match_id]);

    } else {
      // FINAL real → medallero (campeón=3, subcampeón=1)
      const { rows: eqRows } = await client.query(`
        SELECT id, sucursal FROM public.equipos WHERE id = ANY($1::int[])
      `, [[ganadorId, subcampeonId]]);
      const byId = new Map(eqRows.map(r => [r.id, r.sucursal]));
      const sucGan = byId.get(ganadorId)    || 'DESCONOCIDA';
      const sucSub = byId.get(subcampeonId) || 'DESCONOCIDA';

      await client.query(`
        INSERT INTO public.medallero
          (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
        VALUES ($1, 3, $3, $4, $5)
        ON CONFLICT DO NOTHING
      `, [sucGan, 3, P.disciplina_id, P.bracket_id, partidoId]);

      await client.query(`
        INSERT INTO public.medallero
          (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
        VALUES ($1, 1, $3, $4, $5)
        ON CONFLICT DO NOTHING
      `, [sucSub, 1, P.disciplina_id, P.bracket_id, partidoId]);

      try { io.emit('medallero_changed'); } catch {}
    }

    await client.query('COMMIT');
    try { io.emit('partido_updated', { partido_id: partidoId, bracket_id: P.bracket_id }); } catch {}
    res.json({ ok:true, requierePenales:false });

  } catch (err) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error('POST /api/partidos/:id/final error:', err);
    res.status(500).json({ error: 'Error guardando final' });
  } finally {
    client.release();
  }
});


// Medallero
app.get('/api/medallero', requireAuth, async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT sucursal, SUM(puntos)::int AS puntos
        FROM public.medallero
       GROUP BY sucursal
       ORDER BY SUM(puntos) DESC, sucursal ASC`);
    res.json(rows);
  } catch (e) {
    console.error('GET /api/medallero', e);
    res.status(500).json({ error:'Error cargando medallero' });
  }
});

// Último bracket por disciplina
app.get('/api/brackets/byDisciplina/:disciplina_id', requireAuth, async (req, res) => {
  try {
    const did = Number(req.params.disciplina_id || 0);
    if (!did) return res.status(400).json({ error:'disciplina_id inválido' });
    const { rows } = await pool.query(
      `SELECT id FROM public.brackets WHERE disciplina_id=$1 ORDER BY id DESC LIMIT 1`,
      [did]
    );
    if (!rows.length) return res.status(404).json({ error:'Sin brackets para la disciplina' });
    res.json({ bracket_id: rows[0].id });
  } catch (e) {
    console.error('GET /api/brackets/byDisciplina/:disciplina_id', e);
    res.status(500).json({ error:'Error obteniendo bracket' });
  }
});

// Socket.IO
io.on('connection', () => {});

// Arranque
server.listen(PORT, () => {
  console.log(`Servidor escuchando en http://0.0.0.0:${PORT}`);
});
