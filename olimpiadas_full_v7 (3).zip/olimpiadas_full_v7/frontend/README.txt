Cómo correr:
1) Crear DB y ejecutar backend/init.sql en PostgreSQL.
2) Ir a backend/, copiar .env.example a .env y ajustar DATABASE_URL y JWT_SECRET.
3) npm install; npm run seed; npm start
4) Abrir http://localhost:3000/login.html (admin/admin123) para admin.
5) Vista pública: http://localhost:3000/user.html
