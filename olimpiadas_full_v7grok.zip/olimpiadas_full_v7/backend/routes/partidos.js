import express from 'express';
import pool from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = express.Router();

/**
 * Guardar PARCIAL (no altera medallero ni avanza llaves).
 * Body: { parcial_equipo1, parcial_equipo2 }
 */
router.post('/:id/parcial', requireAuth, requireRole('admin','arbitro'), async (req, res) => {
  const id = Number(req.params.id);
  const { parcial_equipo1, parcial_equipo2 } = req.body || {};
  try {
    await pool.query(
      `UPDATE partidos
         SET parcial_equipo1 = $1,
             parcial_equipo2 = $2
       WHERE id = $3`,
      [ Number(parcial_equipo1) ?? null, Number(parcial_equipo2) ?? null, id ]
    );

    // avisar a todos los clientes
    const io = req.app.get('io');
    if (io) io.emit('parcial_actualizado', { partido_id: id });

    res.json({ ok: true });
  } catch (e) {
    console.error('POST /partidos/:id/parcial', e);
    res.status(500).send('Error guardando parcial');
  }
});

/**
 * Guardar RESULTADO FINAL.
 * Body: { puntaje_equipo1, puntaje_equipo2 }
 * - marca partido como finalizado
 * - avanza ganador al next_match (si corresponde)
 * - (el medallero se actualiza en otra ruta/consulta; aquí solo emitimos evento)
 */
router.post('/:id/resultado', requireAuth, requireRole('admin','arbitro'), async (req, res) => {
  const id = Number(req.params.id);
  const a = Number(req.body?.puntaje_equipo1);
  const b = Number(req.body?.puntaje_equipo2);
  if (!Number.isFinite(a) || !Number.isFinite(b) || a === b) {
    return res.status(400).send('Marcador inválido');
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { rows } = await client.query(
      `SELECT id, equipo1_id, equipo2_id, next_match_id, next_match_side
         FROM partidos WHERE id=$1 FOR UPDATE`, [id]
    );
    if (!rows.length) {
      await client.query('ROLLBACK');
      return res.status(404).send('Partido no encontrado');
    }
    const p = rows[0];

    // actualizamos estado y "parciales" = último parcial
    await client.query(
      `UPDATE partidos
          SET estado = 'finalizado',
              parcial_equipo1 = $1,
              parcial_equipo2 = $2
        WHERE id = $3`,
      [a, b, id]
    );

    // si hay tabla resultados, opcionalmente registrá la fila (ignorable si no la usás)
    // await client.query(
    //   `INSERT INTO resultados(partido_id, puntaje_equipo1, puntaje_equipo2)
    //    VALUES($1,$2,$3)`, [id, a, b]
    // );

    // Avanza ganador al próximo partido (si existe)
    if (p.next_match_id) {
      const ganadorId = a > b ? p.equipo1_id : p.equipo2_id;
      const sideCol   = p.next_match_side === 1 ? 'equipo1_id' : 'equipo2_id';

      await client.query(
        `UPDATE partidos SET ${sideCol} = $1 WHERE id = $2`,
        [ganadorId, p.next_match_id]
      );

      // si el “próximo” ya tiene los 2 equipos cargados y no estaba finalizado, queda 'pendiente'
      await client.query(
        `UPDATE partidos
            SET estado = CASE
                           WHEN equipo1_id IS NOT NULL AND equipo2_id IS NOT NULL
                             THEN 'pendiente'
                           ELSE estado
                         END
          WHERE id = $1`, [p.next_match_id]
      );
    }

    await client.query('COMMIT');

    const io = req.app.get('io');
    if (io) io.emit('resultado_actualizado', { partido_id: id });

    res.json({ ok: true });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /partidos/:id/resultado', e);
    res.status(500).send('Error guardando resultado');
  } finally {
    client.release();
  }
});

export default router;
