// backend/routes/brackets.js
import express from 'express';
import pool from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { addMinutes, parseISO } from 'date-fns';

const router = express.Router();

/* ---------- helpers ---------- */

function seeds(teamIds){ return teamIds.slice(); }

/**
 * Crea el árbol de partidos con BYE cuando hay impares.
 * Aseguramos que SIEMPRE se inserte disciplina_id en la tabla partidos.
 */
async function createBracket(client, disciplina_id, nombre, teamIds){
  // 1) Crear el bracket
  const { rows: br } = await client.query(
    'INSERT INTO brackets(disciplina_id, nombre) VALUES ($1,$2) RETURNING id',
    [disciplina_id, nombre || 'Llave']
  );
  const bracketId = br[0].id;

  // 2) Construir rondas
  let current = seeds(teamIds);
  let round = 1;

  while (current.length > 1){
    // Emparejamientos de esta ronda
    const matches = [];
    for (let i=0; i<current.length; i+=2){
      const a = current[i] ?? null;
      const b = (i+1 < current.length) ? current[i+1] : null;
      matches.push([a,b]);
    }

    // Insertar los partidos de la ronda actual
    const mIds = [];
    for (let i=0; i<matches.length; i++){
      const [a,b] = matches[i];
      const estado = (a && b) ? 'pendiente' : 'finalizado';
      const ins = await client.query(
        `INSERT INTO partidos
           (bracket_id, disciplina_id, round, orden, equipo1_id, equipo2_id, estado)
         VALUES ($1,$2,$3,$4,$5,$6,$7)
         RETURNING id`,
        [bracketId, disciplina_id, round, i+1, a, b, estado]
      );
      const pid = ins.rows[0].id;
      mIds.push(pid);

      // Si hay BYE (b=null), dejamos 1–0 como “parcial” simbólico
      if (a && !b){
        await client.query(
          `UPDATE partidos
             SET parcial_equipo1=1, parcial_equipo2=0
           WHERE id=$1`,
          [pid]
        );
      }
    }

    // Crear contenedores de la siguiente ronda
    const nextCount = Math.ceil(mIds.length / 2);
    const nextIds = [];
    for (let i=0; i<nextCount; i++){
      const ins = await client.query(
        `INSERT INTO partidos (bracket_id, disciplina_id, round, orden)
         VALUES ($1,$2,$3,$4) RETURNING id`,
        [bracketId, disciplina_id, round+1, i+1]
      );
      nextIds.push(ins.rows[0].id);
    }

    // Vincular partidos actuales -> próximos (lado 1/2)
    for (let i=0; i<mIds.length; i++){
      const nextIndex = Math.floor(i/2);
      const side = (i % 2) === 0 ? 1 : 2;
      await client.query(
        'UPDATE partidos SET next_match_id=$1, next_match_side=$2 WHERE id=$3',
        [ nextIds[nextIndex], side, mIds[i] ]
      );
    }

    // Empujar BYE al siguiente (lado disponible según índice par/impar)
    for (let i=0; i<matches.length; i++){
      const [a,b] = matches[i];
      if (a && !b){
        const nextIndex = Math.floor(i/2);
        const sideCol = (i % 2) === 0 ? 'equipo1_id' : 'equipo2_id';
        await client.query(
          `UPDATE partidos SET ${sideCol} = $1 WHERE id=$2`,
          [a, nextIds[nextIndex]]
        );
      }
    }

    // Preparar siguiente iteración
    current = new Array(nextIds.length).fill(null);
    round++;
  }

  return bracketId;
}

/* ---------- endpoints ---------- */

/**
 * Generar bracket
 * Body: { disciplina_id, nombre, equipo_ids_en_orden: number[] }
 */
router.post('/generate', requireAuth, requireRole('admin'), async (req, res) => {
  const { disciplina_id, nombre, equipo_ids_en_orden } = req.body || {};
  if (!disciplina_id || !Array.isArray(equipo_ids_en_orden) || equipo_ids_en_orden.length < 3){
    return res.status(400).json({ error: 'Datos inválidos: disciplina y al menos 3 equipos requeridos' });
  }

  const teamIds = equipo_ids_en_orden.map(Number).filter(n => Number.isInteger(n) && n > 0);
  if (teamIds.length !== equipo_ids_en_orden.length) {
    return res.status(400).json({ error: 'Lista de equipos contiene valores inválidos' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Validar existencia de equipos
    const { rows: exists } = await client.query(
      'SELECT id FROM equipos WHERE id = ANY($1::int[])',
      [teamIds]
    );
    const found = new Set(exists.map(r => r.id));
    const missing = teamIds.filter(id => !found.has(id));
    if (missing.length){
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Equipos inexistentes', detalle: { missing } });
    }

    // Validar asignación a disciplina
    const { rows: asign } = await client.query(
      'SELECT equipo_id FROM equipos_disciplinas WHERE disciplina_id=$1 AND equipo_id = ANY($2::int[])',
      [disciplina_id, teamIds]
    );
    const asigSet = new Set(asign.map(r => r.equipo_id));
    const notAssigned = teamIds.filter(id => !asigSet.has(id));
    if (notAssigned.length){
      await client.query('ROLLBACK');
      return res.status(400).json({
        error: 'Algunos equipos no están asignados a la disciplina',
        detalle: { notAssigned }
      });
    }

    // Crear estructura
    const bracketId = await createBracket(client, disciplina_id, nombre, teamIds);

    await client.query('COMMIT');
    return res.json({ ok:true, bracketId });

  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /brackets/generate ERROR:', e);
    return res.status(500).json({ error: 'Error generando bracket', detalle: e.message });
  } finally {
    client.release();
  }
});

/**
 * Programar una ronda
 * Body: { bracket_id, round, start_datetime, interval_minutes }
 */
router.post('/schedule', requireAuth, requireRole('admin','arbitro'), async (req, res) => {
  const { bracket_id, round, start_datetime, interval_minutes } = req.body || {};
  if (!bracket_id || !round || !start_datetime || !interval_minutes) {
    return res.status(400).json({ error: 'Faltan datos' });
  }
  try {
    const { rows } = await pool.query(
      'SELECT id FROM partidos WHERE bracket_id=$1 AND round=$2 ORDER BY orden',
      [bracket_id, round]
    );
    let t = parseISO(start_datetime);
    for (const r of rows){
      await pool.query('UPDATE partidos SET fecha=$1 WHERE id=$2', [t, r.id]);
      t = addMinutes(t, Number(interval_minutes));
    }
    res.json({ ok: true });
  } catch (e) {
    console.error('POST /brackets/schedule', e);
    res.status(500).json({ error: 'Error programando ronda' });
  }
});

/**
 * Mapa de rondas y partidos (para visor y carga)
 */
router.get('/:id/rounds', async (req, res) => {
  const id = Number(req.params.id);
  try {
    const { rows } = await pool.query(
      `SELECT p.*,
              e1.nombre AS n1, e2.nombre AS n2,
              (SELECT r.puntaje_equipo1 FROM resultados r WHERE r.partido_id=p.id ORDER BY id DESC LIMIT 1) AS s1,
              (SELECT r.puntaje_equipo2 FROM resultados r WHERE r.partido_id=p.id ORDER BY id DESC LIMIT 1) AS s2
       FROM partidos p
       LEFT JOIN equipos e1 ON e1.id = p.equipo1_id
       LEFT JOIN equipos e2 ON e2.id = p.equipo2_id
       WHERE p.bracket_id=$1
       ORDER BY p.round, p.orden`,
      [id]
    );
    const map = {};
    for (const r of rows){
      (map[r.round] = map[r.round] || []).push({
        id: r.id, round: r.round, orden: r.orden,
        n1: r.n1, n2: r.n2, s1: r.s1, s2: r.s2,
        parcial_equipo1: r.parcial_equipo1, parcial_equipo2: r.parcial_equipo2,
        fecha: r.fecha, estado: r.estado
      });
    }
    res.json(map);
  } catch (e) {
    console.error('GET /brackets/:id/rounds', e);
    res.status(500).json({ error: 'Error consultando bracket' });
  }
});

export default router;
