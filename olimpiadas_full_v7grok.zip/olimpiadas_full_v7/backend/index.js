// backend/index.js
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';
import { fileURLToPath } from 'url';

import authRoutes from './routes/auth.js';
import disciplinasRoutes from './routes/disciplinas.js';
import equiposRoutes from './routes/equipos.js';
import bracketsRoutes from './routes/brackets.js';
import partidosRoutes from './routes/partidos.js';
import medalleroRoutes from './routes/medallero.js';
import finalesRoutes from './routes/finales.js';

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

app.use((req,_res,next)=>{ req.io = io; next(); });
app.use(cors());
app.use(express.json());

// API
app.use('/api/auth', authRoutes);
app.use('/api/disciplinas', disciplinasRoutes);
app.use('/api/equipos', equiposRoutes);
app.use('/api/brackets', bracketsRoutes);
app.use('/api/partidos', partidosRoutes);
app.use('/api/medallero', medalleroRoutes);
app.use('/api/finales', finalesRoutes);

// Frontend
app.use(express.static(path.join(__dirname, '../frontend')));
app.get('/', (_req,res)=>res.sendFile(path.join(__dirname,'../frontend/login.html')));

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, ()=> console.log('Server http://localhost:'+PORT));
