import express from 'express';
  import { Pool } from 'pg';
  import dotenv from 'dotenv';
  import cors from 'cors';
  import { expressjwt } from 'express-jwt';
  import http from 'http';
  import { Server } from 'socket.io';
  import authRoutes from './routes/auth.js';
  import disciplinasRoutes from './routes/disciplinas.js';
  import bracketsRoutes from './routes/brackets.js';
  import partidosRoutes from './routes/partidos.js';
  import medalleroRoutes from './routes/medallero.js';

  dotenv.config();
  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, { cors: { origin: '*' } });

  app.use(cors());
  app.use(express.json());
  app.use(express.static('.')); // Agregado para servir archivos estáticos desde la raíz

  // Middleware para adjuntar io a req/res
  app.use((req, res, next) => {
    req.io = io;
    next();
  });

  // Middleware JWT
  const authenticateJWT = expressjwt({
    secret: process.env.JWT_SECRET,
    algorithms: ['HS256'],
    getToken: req => req.headers.authorization?.split(' ')[1]
  });

  // Rutas
  app.use('/api/auth', authRoutes);
  app.use('/api/disciplinas', authenticateJWT, disciplinasRoutes);
  app.use('/api/brackets', authenticateJWT, bracketsRoutes);
  app.use('/api/partidos', authenticateJWT, partidosRoutes);
  app.use('/api/medallero', authenticateJWT, medalleroRoutes);

  // WebSocket para actualizaciones en tiempo real
  io.on('connection', (socket) => {
    console.log('Cliente conectado:', socket.id); // Corregido
    socket.on('disconnect', () => console.log('Cliente desconectado:', socket.id));
  });

  const PORT = process.env.PORT || 5000;
  server.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));