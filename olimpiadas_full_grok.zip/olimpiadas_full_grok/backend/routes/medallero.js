import express from 'express';
import pool from '../db.js';

const router = express.Router();

/**
 * Obtener medallero (puntos por sucursal, solo de finales)
 */
router.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT sucursal, SUM(puntos) AS puntos_total FROM medallero_view GROUP BY sucursal ORDER BY puntos_total DESC'
    );
    res.json(rows);
  } catch (e) {
    console.error('GET /medallero ERROR:', e);
    res.status(500).json({ error: 'Error consultando medallero' });
  }
});

export default router;