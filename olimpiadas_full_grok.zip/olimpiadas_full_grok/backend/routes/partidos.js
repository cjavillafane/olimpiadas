import express from 'express';
import pool from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = express.Router();

/**
 * Guardar resultado final de un partido
 * Body: { puntaje_equipo1, puntaje_equipo2 }
 */
router.post('/:id/resultado', requireAuth, requireRole('admin', 'arbitro'), async (req, res) => {
  const partido_id = Number(req.params.id);
  const { puntaje_equipo1, puntaje_equipo2 } = req.body;

  if (!Number.isInteger(partido_id) || partido_id <= 0 || !Number.isInteger(puntaje_equipo1) || !Number.isInteger(puntaje_equipo2) || puntaje_equipo1 === puntaje_equipo2) {
    return res.status(400).json({ error: 'Datos inválidos o empate no permitido' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Determinar ganador
    const ganador_id = puntaje_equipo1 > puntaje_equipo2 ? (await client.query('SELECT equipo1_id FROM partidos WHERE id=$1', [partido_id])).rows[0].equipo1_id : (await client.query('SELECT equipo2_id FROM partidos WHERE id=$1', [partido_id])).rows[0].equipo2_id;

    // Insertar resultado
    await client.query(
      'INSERT INTO resultados (partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id) VALUES ($1, $2, $3, $4)',
      [partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id]
    );

    // Actualizar estado del partido
    await client.query(
      'UPDATE partidos SET estado = $1 WHERE id = $2',
      ['finalizado', partido_id]
    );

    // Verificar si es la final (next_match_id IS NULL)
    const { rows: isFinal } = await client.query('SELECT next_match_id FROM partidos WHERE id = $1', [partido_id]);
    if (isFinal[0].next_match_id === null) {
      // Si es final, actualizar estado y emitir evento (puntos se calculan en la vista)
      // No se necesita inserción adicional, la vista medallero_view lo maneja
      res.io.emit('resultado_actualizado', { partido_id });
    }

    // Avanzar ganador a siguiente partido si no es final
    if (isFinal[0].next_match_id !== null) {
      const { rows: next } = await client.query('SELECT next_match_id, next_match_side FROM partidos WHERE id = $1', [partido_id]);
      const sideCol = next[0].next_match_side === 1 ? 'equipo1_id' : 'equipo2_id';
      await client.query(
        `UPDATE partidos SET ${sideCol} = $1 WHERE id = $2`,
        [ganador_id, next[0].next_match_id]
      );
    }

    await client.query('COMMIT');
    return res.json({ ok: true });

  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /partidos/:id/resultado ERROR:', e);
    return res.status(500).json({ error: 'Error guardando resultado', detalle: e.message });
  } finally {
    client.release();
  }
});

// Otros endpoints para parciales, etc., si los tienes
router.post('/:id/parcial', requireAuth, requireRole('admin', 'arbitro'), async (req, res) => {
  const partido_id = Number(req.params.id);
  const { parcial_equipo1, parcial_equipo2 } = req.body;

  if (!Number.isInteger(partido_id) || partido_id <= 0 || !Number.isInteger(parcial_equipo1) || !Number.isInteger(parcial_equipo2)) {
    return res.status(400).json({ error: 'Datos inválidos' });
  }

  try {
    await pool.query(
      'UPDATE partidos SET parcial_equipo1 = $1, parcial_equipo2 = $2, parcial_actualizado_en = now() WHERE id = $3',
      [parcial_equipo1, parcial_equipo2, partido_id]
    );
    res.io.emit('parcial_actualizado', { partido_id });
    return res.json({ ok: true });
  } catch (e) {
    console.error('POST /partidos/:id/parcial ERROR:', e);
    return res.status(500).json({ error: 'Error guardando parcial', detalle: e.message });
  }
});

export default router;