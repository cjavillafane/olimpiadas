import express from 'express';
import pool from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { addMinutes, parseISO } from 'date-fns';

const router = express.Router();

/* ---------- helpers ---------- */

function seeds(teamIds) { return teamIds.slice(); }

/**
 * Crea el árbol de partidos con BYE cuando hay impares.
 * Para 5 equipos en orden [Catamarca, Córdoba, La Rioja, Salta, San Juan]:
 * - Ronda 1: Catamarca vs Córdoba, La Rioja vs Salta, San Juan vs BYE.
 * - Ronda 2: Ganador Catamarca-Córdoba vs BYE (libre), Ganador La Rioja-Salta vs Ganador San Juan-BYE.
 * - Final: Ganador Ronda 2-1 vs Ganador Ronda 2-2.
 */
async function createBracketFromTemplate(client, disciplina_id, nombre, teamIds, template = null) {
  console.log('Creando bracket con discipline_id:', disciplina_id);
  if (!Number.isInteger(disciplina_id) || disciplina_id <= 0) {
    throw new Error('disciplina_id debe ser un número entero positivo');
  }

  // 1) Crear el bracket
  const { rows: br } = await client.query(
    'INSERT INTO brackets(disciplina_id, nombre) VALUES ($1,$2) RETURNING id',
    [disciplina_id, nombre || 'Llave']
  );
  const bracketId = br[0].id;

  // 2) Construir rondas
  let current = seeds(teamIds);
  let round = 1;

  while (current.length > 1) {
    const matches = [];
    if (current.length === 5) {
      // Lógica específica para 5 equipos
      matches.push([current[0], current[1]]); // Catamarca vs Córdoba
      matches.push([current[2], current[3]]); // La Rioja vs Salta
      matches.push([current[4], null]);       // San Juan vs BYE
    } else {
      for (let i = 0; i < current.length; i += 2) {
        const a = current[i] ?? null;
        const b = (i + 1 < current.length) ? current[i + 1] : null;
        matches.push([a, b]);
      }
    }

    const mIds = [];
    for (let i = 0; i < matches.length; i++) {
      const [a, b] = matches[i];
      const estado = (a && b) ? 'pendiente' : 'finalizado';
      const ins = await client.query(
        `INSERT INTO partidos
           (bracket_id, disciplina_id, round, orden, equipo1_id, equipo2_id, estado)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         RETURNING id`,
        [bracketId, disciplina_id, round, i + 1, a, b, estado]
      );
      const pid = ins.rows[0].id;
      mIds.push(pid);

      if (a && !b) {
        await client.query(
          `UPDATE partidos
             SET parcial_equipo1=1, parcial_equipo2=0
           WHERE id=$1`,
          [pid]
        );
      }
    }

    const nextCount = Math.ceil(mIds.length / 2);
    const nextIds = [];
    for (let i = 0; i < nextCount; i++) {
      const ins = await client.query(
        `INSERT INTO partidos (bracket_id, disciplina_id, round, orden)
         VALUES ($1, $2, $3, $4) RETURNING id`,
        [bracketId, disciplina_id, round + 1, i + 1]
      );
      nextIds.push(ins.rows[0].id);
    }

    for (let i = 0; i < mIds.length; i++) {
      const nextIndex = Math.floor(i / 2);
      const side = (i % 2) === 0 ? 1 : 2;
      await client.query(
        'UPDATE partidos SET next_match_id=$1, next_match_side=$2 WHERE id=$3',
        [nextIds[nextIndex], side, mIds[i]]
      );
    }

    for (let i = 0; i < matches.length; i++) {
      const [a, b] = matches[i];
      if (a && !b) {
        const nextIndex = Math.floor(i / 2);
        const sideCol = (i % 2) === 0 ? 'equipo1_id' : 'equipo2_id';
        await client.query(
          `UPDATE partidos SET ${sideCol} = $1 WHERE id=$2`,
          [a, nextIds[nextIndex]]
        );
      }
    }

    current = new Array(nextIds.length).fill(null);
    round++;
  }

  return bracketId;
}

/* ---------- endpoints ---------- */

/**
 * Generar bracket
 * Body: { disciplina_id, nombre, equipo_ids_en_orden: number[] }
 */
router.post('/generate', requireAuth, requireRole('admin'), async (req, res) => {
  console.log('Req.body recibido en /generate:', req.body);
  const { disciplina_id, nombre, equipo_ids_en_orden } = req.body || {};
  if (!Number.isInteger(disciplina_id) || disciplina_id <= 0 || !Array.isArray(equipo_ids_en_orden) || equipo_ids_en_orden.length < 3) {
    return res.status(400).json({ error: 'Datos inválidos: discipline_id debe ser un número entero positivo, y al menos 3 equipos requeridos' });
  }

  const teamIds = equipo_ids_en_orden.map(Number).filter(n => Number.isInteger(n) && n > 0);
  if (teamIds.length !== equipo_ids_en_orden.length) {
    return res.status(400).json({ error: 'Lista de equipos contiene valores inválidos' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { rows: exists } = await client.query(
      'SELECT id FROM equipos WHERE id = ANY($1::int[])',
      [teamIds]
    );
    const found = new Set(exists.map(r => r.id));
    const missing = teamIds.filter(id => !found.has(id));
    if (missing.length) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Equipos inexistentes', detalle: { missing } });
    }

    const { rows: asign } = await client.query(
      'SELECT equipo_id FROM equipos_disciplinas WHERE disciplina_id=$1 AND equipo_id = ANY($2::int[])',
      [disciplina_id, teamIds]
    );
    const asigSet = new Set(asign.map(r => r.equipo_id));
    const notAssigned = teamIds.filter(id => !asigSet.has(id));
    if (notAssigned.length) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        error: 'Algunos equipos no están asignados a la disciplina',
        detalle: { notAssigned }
      });
    }

    const bracketId = await createBracketFromTemplate(client, disciplina_id, nombre, teamIds);

    await client.query('COMMIT');
    return res.json({ ok: true, bracketId });

  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /brackets/generate ERROR:', e);
    return res.status(500).json({ error: 'Error generando bracket', detalle: e.message });
  } finally {
    client.release();
  }
});

/**
 * Programar una ronda
 * Body: { bracket_id, round, start_datetime, interval_minutes }
 */
router.post('/schedule', requireAuth, requireRole('admin','arbitro'), async (req, res) => {
  const { bracket_id, round, start_datetime, interval_minutes } = req.body || {};
  if (!bracket_id || !round || !start_datetime || !interval_minutes) {
    return res.status(400).json({ error: 'Faltan datos' });
  }
  try {
    const { rows } = await pool.query(
      'SELECT id FROM partidos WHERE bracket_id=$1 AND round=$2 ORDER BY orden',
      [bracket_id, round]
    );
    let t = parseISO(start_datetime);
    for (const r of rows) {
      await pool.query('UPDATE partidos SET fecha=$1 WHERE id=$2', [t, r.id]);
      t = addMinutes(t, Number(interval_minutes));
    }
    res.json({ ok: true });
  } catch (e) {
    console.error('POST /brackets/schedule', e);
    res.status(500).json({ error: 'Error programando ronda' });
  }
});

/**
 * Mapa de rondas y partidos (para visor y carga)
 */
router.get('/:id/rounds', async (req, res) => {
  const id = Number(req.params.id);
  try {
    const { rows } = await pool.query(
      `SELECT p.*,
              e1.nombre AS n1, e2.nombre AS n2,
              (SELECT r.puntaje_equipo1 FROM resultados r WHERE r.partido_id=p.id ORDER BY id DESC LIMIT 1) AS s1,
              (SELECT r.puntaje_equipo2 FROM resultados r WHERE r.partido_id=p.id ORDER BY id DESC LIMIT 1) AS s2
       FROM partidos p
       LEFT JOIN equipos e1 ON e1.id = p.equipo1_id
       LEFT JOIN equipos e2 ON e2.id = p.equipo2_id
       WHERE p.bracket_id=$1
       ORDER BY p.round, p.orden`,
      [id]
    );
    const map = {};
    for (const r of rows) {
      (map[r.round] = map[r.round] || []).push({
        id: r.id, round: r.round, orden: r.orden,
        n1: r.n1, n2: r.n2, s1: r.s1, s2: r.s2,
        parcial_equipo1: r.parcial_equipo1, parcial_equipo2: r.parcial_equipo2,
        fecha: r.fecha, estado: r.estado
      });
    }
    res.json(map);
  } catch (e) {
    console.error('GET /brackets/:id/rounds', e);
    res.status(500).json({ error: 'Error consultando bracket' });
  }
});

export default router;