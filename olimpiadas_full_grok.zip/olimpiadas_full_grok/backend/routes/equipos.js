// backend/routes/equipos.js
import express from 'express';
import pool from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
const router = express.Router();

router.get('/', async (req, res) => {
  const { disciplina_id } = req.query;
  try {
    if (disciplina_id) {
      const ids = await pool.query('SELECT equipo_id FROM equipos_disciplinas WHERE disciplina_id=$1 ORDER BY equipo_id', [disciplina_id]);
      if (!ids.rows.length) return res.json([]);
      const arr = ids.rows.map(r => r.equipo_id);
      const { rows } = await pool.query('SELECT id, nombre, sucursal FROM equipos WHERE id = ANY($1::int[]) ORDER BY nombre', [arr]);
      return res.json(rows);
    }
    const { rows } = await pool.query('SELECT id, nombre, sucursal FROM equipos ORDER BY nombre');
    res.json(rows);
  } catch (e) {
    console.error('GET /equipos', e);
    res.status(500).json({ error: 'Error listando equipos' });
  }
});

router.get('/asignados', async (req, res) => {
  const { disciplina_id } = req.query;
  if (!disciplina_id) return res.json([]);
  try {
    const { rows } = await pool.query('SELECT equipo_id FROM equipos_disciplinas WHERE disciplina_id=$1 ORDER BY equipo_id', [disciplina_id]);
    res.json(rows.map(r => r.equipo_id));
  } catch (e) {
    console.error('GET /equipos/asignados', e);
    res.status(500).json({ error: 'Error listando asignados' });
  }
});

router.post('/asignar', requireAuth, requireRole('admin'), async (req, res) => {
  const { equipo_id, disciplina_id } = req.body;
  if (!equipo_id || !disciplina_id) return res.status(400).json({ error: 'equipo_id y disciplina_id requeridos' });
  try {
    await pool.query('INSERT INTO equipos_disciplinas(equipo_id, disciplina_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [equipo_id, disciplina_id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('POST /equipos/asignar', e);
    res.status(500).json({ error: 'Error asignando equipo' });
  }
});

router.delete('/asignar', requireAuth, requireRole('admin'), async (req, res) => {
  const { equipo_id, disciplina_id } = req.body;
  if (!equipo_id || !disciplina_id) return res.status(400).json({ error: 'equipo_id y disciplina_id requeridos' });
  try {
    await pool.query('DELETE FROM equipos_disciplinas WHERE equipo_id=$1 AND disciplina_id=$2', [equipo_id, disciplina_id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('DELETE /equipos/asignar', e);
    res.status(500).json({ error: 'Error quitando asignación' });
  }
});

export default router;
