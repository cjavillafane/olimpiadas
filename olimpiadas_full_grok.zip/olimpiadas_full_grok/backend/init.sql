CREATE TABLE IF NOT EXISTS usuarios (
  id SERIAL PRIMARY KEY,
  usuario TEXT UNIQUE NOT NULL,
  clave_hash TEXT NOT NULL,
  rol TEXT NOT NULL CHECK (rol IN ('admin','arbitro','visor'))
);
CREATE TABLE IF NOT EXISTS disciplinas ( id SERIAL PRIMARY KEY, nombre TEXT NOT NULL );
CREATE TABLE IF NOT EXISTS equipos ( id SERIAL PRIMARY KEY, nombre TEXT NOT NULL, sucursal TEXT NOT NULL );
CREATE TABLE IF NOT EXISTS equipos_disciplinas (
  equipo_id INT REFERENCES equipos(id) ON DELETE CASCADE,
  disciplina_id INT REFERENCES disciplinas(id) ON DELETE CASCADE,
  PRIMARY KEY (equipo_id, disciplina_id)
);
CREATE TABLE IF NOT EXISTS brackets ( id SERIAL PRIMARY KEY, disciplina_id INT NOT NULL REFERENCES disciplinas(id) ON DELETE CASCADE, nombre TEXT NOT NULL, creado_en TIMESTAMP DEFAULT NOW() );
CREATE TABLE IF NOT EXISTS partidos (
  id SERIAL PRIMARY KEY,
  disciplina_id INT NOT NULL REFERENCES disciplinas(id) ON DELETE CASCADE,
  equipo1_id INT REFERENCES equipos(id),
  equipo2_id INT REFERENCES equipos(id),
  fecha TIMESTAMP,
  estado VARCHAR(20) DEFAULT 'pendiente',
  round INT,
  bracket_id INT REFERENCES brackets(id),
  next_match_id INT,
  next_match_side SMALLINT
);
CREATE TABLE IF NOT EXISTS resultados (
  id SERIAL PRIMARY KEY,
  partido_id INT NOT NULL REFERENCES partidos(id) ON DELETE CASCADE,
  puntaje_equipo1 INT NOT NULL DEFAULT 0,
  puntaje_equipo2 INT NOT NULL DEFAULT 0,
  ganador_id INT REFERENCES equipos(id),
  registrado_en TIMESTAMP DEFAULT NOW()
);
