// backend/seed_admin.js
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import pool from './db.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

async function seed(){
  try {
    const __dirname = path.dirname(fileURLToPath(import.meta.url));
    const initSQL = fs.readFileSync(path.join(__dirname, 'init.sql'), 'utf8');
    await pool.query(initSQL);

    const user = 'admin';
    const pass = 'admin123';
    const role = 'admin';
    const exists = await pool.query('SELECT 1 FROM usuarios WHERE usuario=$1', [user]);
    if (!exists.rows.length){
      const hash = await bcrypt.hash(pass, 10);
      await pool.query('INSERT INTO usuarios(usuario, clave_hash, rol) VALUES ($1,$2,$3)', [user, hash, role]);
      console.log('Usuario admin creado: admin / admin123');
    } else {
      console.log('Usuario admin ya existe');
    }

    const d = await pool.query('SELECT 1 FROM disciplinas LIMIT 1');
    if (!d.rows.length){
      await pool.query("INSERT INTO disciplinas(nombre) VALUES ('Futbol Primera'),('Voley'),('Basquet')");
    }
    const e = await pool.query('SELECT 1 FROM equipos LIMIT 1');
    if (!e.rows.length){
      await pool.query(`
        INSERT INTO equipos(nombre, sucursal) VALUES
        ('Tucuman','Tucuman'),
        ('Salta','Salta'),
        ('Cordoba','Cordoba'),
        ('La Rioja','La Rioja'),
        ('Catamarca','Catamarca'),
        ('San Juan','San Juan'),
        ('Santiago del Estero','Sgo. del Estero'),
        ('Jujuy','Jujuy')
      `);
    }
    console.log('Seed OK');
    process.exit(0);
  } catch (e) {
    console.error('Seed error', e);
    process.exit(1);
  }
}
seed();
