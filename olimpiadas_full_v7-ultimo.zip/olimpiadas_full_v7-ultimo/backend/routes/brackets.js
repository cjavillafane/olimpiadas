// backend/routes/brackets.js
import express from 'express';
import pool from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { addMinutes, parseISO } from 'date-fns';
import { getTemplateByCount } from '../bracket_templates.js';

const router = express.Router();

/* ========================= Helpers comunes ========================= */

async function insertMatch(client, {
  disciplina_id,
  bracket_id,
  round,
  orden,
  equipo1_id = null,
  equipo2_id = null,
  estado = 'pendiente',
  fecha = null,
  next_match_id = null,
  next_match_side = null
}) {
  const { rows } = await client.query(
    `INSERT INTO partidos
      (disciplina_id, bracket_id, round, orden,
       equipo1_id, equipo2_id, estado, fecha,
       next_match_id, next_match_side)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     RETURNING id`,
    [disciplina_id, bracket_id, round, orden,
     equipo1_id, equipo2_id, estado, fecha,
     next_match_id, next_match_side]
  );
  return rows[0].id;
}

/* ===================== Generador genérico (fallback) ===================== */

function seeds(list) { return list.slice(); }

async function createBracketGeneric(client, disciplina_id, nombre, teamIds) {
  const { rows: br } = await client.query(
    'INSERT INTO brackets(disciplina_id, nombre) VALUES ($1,$2) RETURNING id',
    [disciplina_id, nombre || 'Llave']
  );
  const bracketId = br[0].id;

  let current = seeds(teamIds);
  let round = 1;

  while (current.length > 1) {
    const pairs = [];
    for (let i = 0; i < current.length; i += 2) {
      const a = current[i] ?? null;
      const b = (i + 1 < current.length) ? current[i + 1] : null;
      pairs.push([a, b]);
    }

    const matchIds = [];
    for (let i = 0; i < pairs.length; i++) {
      const [a, b] = pairs[i];
      const estado = (a && b) ? 'pendiente' : 'finalizado';
      const pid = await insertMatch(client, {
        disciplina_id, bracket_id: bracketId, round, orden: i + 1,
        equipo1_id: a, equipo2_id: b, estado
      });
      matchIds.push(pid);
    }

    const nextCount = Math.ceil(matchIds.length / 2);
    const nextIds = [];
    for (let i = 0; i < nextCount; i++) {
      const nid = await insertMatch(client, {
        disciplina_id, bracket_id: bracketId,
        round: round + 1, orden: i + 1,
        estado: 'pendiente'
      });
      nextIds.push(nid);
    }

    for (let i = 0; i < matchIds.length; i++) {
      const nextIndex = Math.floor(i / 2);
      const side = (i % 2) === 0 ? 1 : 2;
      await client.query(
        'UPDATE partidos SET next_match_id=$1, next_match_side=$2 WHERE id=$3',
        [nextIds[nextIndex], side, matchIds[i]]
      );
    }

    for (let i = 0; i < pairs.length; i++) {
      const [a, b] = pairs[i];
      if (a && !b) {
        const nextIndex = Math.floor(i / 2);
        const sideCol = (i % 2) === 0 ? 'equipo1_id' : 'equipo2_id';
        await client.query(`UPDATE partidos SET ${sideCol}=$1 WHERE id=$2`, [a, nextIds[nextIndex]]);
      }
    }

    current = new Array(nextIds.length).fill(null);
    round++;
  }

  return bracketId;
}

/* =================== Generador por PLANTILLAS 3–11 =================== */

async function createBracketFromTemplate(client, disciplina_id, nombre, teamIds) {
  const tpl = getTemplateByCount(teamIds.length);
  if (!tpl) {
    // Sin plantilla: usar generador genérico
    return createBracketGeneric(client, disciplina_id, nombre, teamIds);
  }

  // 1) crear el bracket
  const { rows: br } = await client.query(
    'INSERT INTO brackets(disciplina_id, nombre) VALUES ($1,$2) RETURNING id',
    [disciplina_id, nombre || 'Llave']
  );
  const bracketId = br[0].id;

  // 2) crear matches vacíos (por ronda/orden) y guardar sus IDs por id de plantilla
  //    Si en la plantilla ya hay un seed fijo (número), lo colocamos en equipo1/2.
  const idMap = new Map(); // 'Mx' -> partido.id

  // Para buscar rápidamente el match destino al que “alimenta” el ganador
  const lookupByRoundOrden = {};

  for (const def of tpl) {
    if (!def) continue;
    if (def.a === null && def.b === null && !def.next) {
      // placeholders (como M6 en 11 equipos) no se insertan
      continue;
    }

    const equipo1_id = typeof def.a === 'number' ? (teamIds[def.a - 1] ?? null) : null;
    const equipo2_id = typeof def.b === 'number' ? (teamIds[def.b - 1] ?? null) : null;

    const pid = await insertMatch(client, {
      disciplina_id,
      bracket_id: bracketId,
      round: def.round,
      orden: def.orden,
      equipo1_id,
      equipo2_id,
      estado: (equipo1_id && equipo2_id) ? 'pendiente' : 'pendiente'
    });

    idMap.set(def.id, pid);
    (lookupByRoundOrden[def.round] = lookupByRoundOrden[def.round] || {})[def.orden] = pid;
  }

  // 3) Actualizar next_match_id/side y completar equipos “colocados” por plantilla
  for (const def of tpl) {
    const pid = idMap.get(def.id);
    if (!pid) continue;

    // Enlaces de ganador -> siguiente
    if (def.next) {
      const targetId = idMap.get(def.next);
      if (targetId) {
        await client.query(
          'UPDATE partidos SET next_match_id=$1, next_match_side=$2 WHERE id=$3',
          [targetId, def.nextSide ?? 1, pid]
        );
      }
    }

    // Si 'a' o 'b' son 'W:Mx', NO ponemos equipo aquí (llega por el flujo del ganador).
    // Si 'a' o 'b' son números ya se cargó al insertar.
    // Si 'a' o 'b' es un número que representa un libre “entrando” en rondas superiores
    // ya lo cargamos al crear ese match (ej.: 5 en semi para 5 equipos).
  }

  return bracketId;
}

/* ============================ Endpoints ============================ */

router.post('/generate', requireAuth, requireRole('admin'), async (req, res) => {
  const { disciplina_id, nombre, equipo_ids_en_orden } = req.body || {};
  if (!disciplina_id || !Array.isArray(equipo_ids_en_orden) || equipo_ids_en_orden.length < 3) {
    return res.status(400).json({ error: 'Datos inválidos: disciplina y al menos 3 equipos requeridos' });
  }

  const teamIds = equipo_ids_en_orden.map(Number).filter(n => Number.isInteger(n) && n > 0);
  if (teamIds.length !== equipo_ids_en_orden.length) {
    return res.status(400).json({ error: 'Lista de equipos contiene valores inválidos' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Validaciones mínimas
    const dsc = await client.query('SELECT id FROM disciplinas WHERE id=$1', [disciplina_id]);
    if (dsc.rowCount === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Disciplina inexistente' });
    }

    const { rows: exists } = await client.query(
      'SELECT id FROM equipos WHERE id = ANY($1::int[])',
      [teamIds]
    );
    const have = new Set(exists.map(r => r.id));
    const missing = teamIds.filter(id => !have.has(id));
    if (missing.length) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Equipos inexistentes', detalle: { missing } });
    }

    const { rows: asg } = await client.query(
      'SELECT equipo_id FROM equipos_disciplinas WHERE disciplina_id=$1 AND equipo_id = ANY($2::int[])',
      [disciplina_id, teamIds]
    );
    const okSet = new Set(asg.map(r => r.equipo_id));
    const notAssigned = teamIds.filter(id => !okSet.has(id));
    if (notAssigned.length) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Equipos no asignados a la disciplina', detalle: { notAssigned } });
    }

    // Generar usando plantilla cuando haya (3–11), si no: genérico
    const bracketId = await createBracketFromTemplate(client, disciplina_id, nombre, teamIds);

    await client.query('COMMIT');
    return res.json({ ok: true, bracketId });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /brackets/generate ERROR:', e);
    return res.status(500).json({ error: 'Error generando bracket', detalle: e.message });
  } finally {
    client.release();
  }
});

router.post('/schedule', requireAuth, requireRole('admin','arbitro'), async (req, res) => {
  const { bracket_id, round, start_datetime, interval_minutes } = req.body || {};
  if (!bracket_id || !round || !start_datetime || !interval_minutes) {
    return res.status(400).json({ error: 'Faltan datos' });
  }
  try {
    const { rows } = await pool.query(
      'SELECT id FROM partidos WHERE bracket_id=$1 AND round=$2 ORDER BY orden',
      [bracket_id, round]
    );
    let t = parseISO(start_datetime);
    for (const r of rows) {
      await pool.query('UPDATE partidos SET fecha=$1 WHERE id=$2', [t, r.id]);
      t = addMinutes(t, Number(interval_minutes));
    }
    res.json({ ok: true });
  } catch (e) {
    console.error('POST /brackets/schedule', e);
    res.status(500).json({ error: 'Error programando ronda' });
  }
});

router.get('/:id/rounds', async (req, res) => {
  const id = Number(req.params.id);
  try {
    const { rows } = await pool.query(
      `SELECT p.*,
              e1.nombre AS n1, e2.nombre AS n2,
              (SELECT r.puntaje_equipo1 FROM resultados r WHERE r.partido_id=p.id ORDER BY r.id DESC LIMIT 1) AS s1,
              (SELECT r.puntaje_equipo2 FROM resultados r WHERE r.partido_id=p.id ORDER BY r.id DESC LIMIT 1) AS s2
         FROM partidos p
    LEFT JOIN equipos e1 ON e1.id = p.equipo1_id
    LEFT JOIN equipos e2 ON e2.id = p.equipo2_id
        WHERE p.bracket_id=$1
     ORDER BY p.round, p.orden`,
      [id]
    );
    const map = {};
    for (const r of rows) {
      (map[r.round] = map[r.round] || []).push({
        id: r.id, round: r.round, orden: r.orden,
        n1: r.n1, n2: r.n2, s1: r.s1, s2: r.s2,
        parcial_equipo1: r.parcial_equipo1, parcial_equipo2: r.parcial_equipo2,
        fecha: r.fecha, estado: r.estado
      });
    }
    res.json(map);
  } catch (e) {
    console.error('GET /brackets/:id/rounds', e);
    res.status(500).json({ error: 'Error consultando bracket' });
  }
});

router.get('/byDisciplina/:id', requireAuth, async (req, res) => {
  try {
    const disciplinaId = Number(req.params.id || 0);
    if (!disciplinaId) return res.status(400).json({ error: 'disciplina_id inválido' });

    // Tomamos el último bracket de esa disciplina (cambiá ORDER BY si prefieres otro criterio)
    const { rows: bRows } = await pool.query(
      `SELECT id
         FROM public.brackets
        WHERE disciplina_id = $1
        ORDER BY id DESC
        LIMIT 1`,
      [disciplinaId]
    );
    if (bRows.length === 0) return res.status(404).json({ error: 'Sin bracket para esta disciplina' });

    const bracketId = bRows[0].id;

    const { rows: mRows } = await pool.query(`
      SELECT
        p.id, p.bracket_id, p.disciplina_id, p.round, p.orden,
        p.equipo1_id, p.equipo2_id, p.next_match_id,
        p.estado, p.fecha,
        p.parcial_equipo1, p.parcial_equipo2,
        e1.nombre AS n1, e2.nombre AS n2,
        r.puntaje_equipo1 AS s1, r.puntaje_equipo2 AS s2
      FROM public.partidos p
      LEFT JOIN public.equipos e1 ON e1.id = p.equipo1_id
      LEFT JOIN public.equipos e2 ON e2.id = p.equipo2_id
      LEFT JOIN public.resultados r ON r.partido_id = p.id
      WHERE p.bracket_id = $1
      ORDER BY p.round, p.orden, p.id
    `, [bracketId]);

    const rounds = {};
    for (const m of mRows) {
      if (!rounds[m.round]) rounds[m.round] = [];
      rounds[m.round].push(m);
    }

    res.json({ bracket_id: bracketId, rounds });
  } catch (err) {
    console.error('GET /api/brackets/byDisciplina/:id error:', err);
    res.status(500).json({ error: 'Error cargando bracket por disciplina' });
  }
});


export default router;
