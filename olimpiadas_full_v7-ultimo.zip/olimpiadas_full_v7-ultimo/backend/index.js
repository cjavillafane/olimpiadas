// backend/index.js
import express from 'express';
import http from 'http';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { Server as IOServer } from 'socket.io';
import dotenv from 'dotenv';

import pool from './db.js';
import authRouter from './routes/auth.js';
import bracketsRouter from './routes/brackets.js';
// ⬇️ CORRECCIÓN: importar también requireRole
import { requireAuth, requireRole } from './middleware/auth.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const ORIGIN = process.env.CORS_ORIGIN || '*';

const app = express();
const server = http.createServer(app);
const io = new IOServer(server, {
  cors: { origin: ORIGIN, methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'] },
  path: '/socket.io/'
});

// dejar io disponible en los handlers
app.set('io', io);

// middlewares
app.use(cors({ origin: ORIGIN }));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// servir frontend estático (carpeta /frontend del repo)
app.use(express.static(path.join(__dirname, '../frontend')));

// ---------- Rutas existentes ----------
app.use('/auth', authRouter); 
app.use('/api/auth', authRouter);                // login
app.use('/api/brackets', bracketsRouter);     // generación / rounds / schedule

// ---------- Rutas que espera admin.html ----------

// Disciplinas
app.get('/api/disciplinas', requireAuth, async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, nombre FROM disciplinas ORDER BY nombre');
    res.json(rows);
  } catch (e) {
    console.error('GET /api/disciplinas', e);
    res.status(500).json({ error: 'Error cargando disciplinas' });
  }
});

// Equipos (todos o asignados a una disciplina)
app.get('/api/equipos', requireAuth, async (req, res) => {
  try {
    const did = Number(req.query.disciplina_id || 0);
    if (did) {
      const { rows } = await pool.query(
        `SELECT e.id, e.nombre
           FROM equipos e
           JOIN equipos_disciplinas ed ON ed.equipo_id = e.id
          WHERE ed.disciplina_id = $1
          ORDER BY e.nombre`, [did]
      );
      return res.json(rows);
    }
    const { rows } = await pool.query('SELECT id, nombre FROM equipos ORDER BY nombre');
    res.json(rows);
  } catch (e) {
    console.error('GET /api/equipos', e);
    res.status(500).json({ error: 'Error cargando equipos' });
  }
});

// IDs asignados a una disciplina (para tildar checkboxes)
app.get('/api/asignados', requireAuth, async (req, res) => {
  try {
    const did = Number(req.query.disciplina_id || 0);
    if (!did) return res.json([]);
    const { rows } = await pool.query(
      'SELECT equipo_id FROM equipos_disciplinas WHERE disciplina_id=$1 ORDER BY equipo_id',
      [did]
    );
    res.json(rows); // [{equipo_id:...}, ...]
  } catch (e) {
    console.error('GET /api/asignados', e);
    res.status(500).json({ error: 'Error cargando asignaciones' });
  }
});

// Guardar asignaciones (reemplaza TODAS las de esa disciplina por las enviadas)
app.post('/api/asignar_equipos', requireAuth, async (req, res) => {
  const { disciplina_id, equipo_ids } = req.body || {};
  if (!disciplina_id || !Array.isArray(equipo_ids)) {
    return res.status(400).json({ error: 'Datos inválidos' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM equipos_disciplinas WHERE disciplina_id=$1', [disciplina_id]);

    if (equipo_ids.length) {
      const values = equipo_ids.map((_, i) => `($1,$${i + 2})`).join(',');
      await client.query(
        `INSERT INTO equipos_disciplinas (disciplina_id, equipo_id) VALUES ${values}`,
        [disciplina_id, ...equipo_ids]
      );
    }

    await client.query('COMMIT');
    res.json({ ok: true });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('POST /api/asignar_equipos', e);
    res.status(500).json({ error: 'Error guardando asignaciones' });
  } finally {
    client.release();
  }
});

// Guardar PARCIAL
app.post('/api/partidos/:id/parcial', requireAuth, async (req, res) => {
  const id = Number(req.params.id);
  const { parcial_equipo1 = 0, parcial_equipo2 = 0 } = req.body || {};
  try {
    const { rows } = await pool.query(
      `UPDATE partidos
          SET parcial_equipo1=$1,
              parcial_equipo2=$2,
              parcial_actualizado_en=NOW()
        WHERE id=$3
        RETURNING id, bracket_id`,
      [parcial_equipo1, parcial_equipo2, id]
    );
    const r = rows[0];
    try { app.get('io')?.emit('partido_updated', { partido_id: id, bracket_id: r?.bracket_id }); } catch {}
    res.json({ ok: true });
  } catch (e) {
    console.error('POST /api/partidos/:id/parcial', e);
    res.status(500).json({ error: 'Error guardando parcial' });
  }
});

// Guardar FINAL (resultado + medallero si es el partido final del bracket)
/*  app.post('/api/partidos/:id/final', requireAuth, requireRole('admin','arbitro'), async (req, res) => {
  const client = await pool.connect();
  try {
    const partidoId = Number(req.params.id);
    const { puntaje_equipo1, puntaje_equipo2 } = req.body || {};

    const { rows: pRows } = await client.query(`
      SELECT p.id, p.bracket_id, p.disciplina_id, p.round, p.orden,
             p.equipo1_id, p.equipo2_id,
             p.next_match_id
      FROM public.partidos p
      WHERE p.id = $1
      LIMIT 1
    `, [partidoId]);

    if (pRows.length === 0) return res.status(404).json({ error: 'Partido no encontrado' });
    const P = pRows[0];

    if (!P.equipo1_id || !P.equipo2_id) {
      return res.status(400).json({ error: 'Partido incompleto' });
    }
    if (P.next_match_id !== null) {
      return res.status(400).json({ error: 'No es el partido final del bracket' });
    }

    const s1 = Number(puntaje_equipo1) || 0;
    const s2 = Number(puntaje_equipo2) || 0;
    if (s1 === s2) return res.status(400).json({ error: 'El final no puede terminar empatado' });

    const ganadorId    = s1 > s2 ? P.equipo1_id : P.equipo2_id;
    const subcampeonId = s1 > s2 ? P.equipo2_id : P.equipo1_id;

    await client.query('BEGIN');

    await client.query(`
      INSERT INTO public.resultados(partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id)
      VALUES ($1, $2, $3, $4)
    `, [partidoId, s1, s2, ganadorId]);

    await client.query(`
      UPDATE public.partidos SET estado='finalizado' WHERE id=$1
    `, [partidoId]);

    const { rows: eqRows } = await client.query(`
      SELECT e.id, e.sucursal
      FROM public.equipos e
      WHERE e.id = ANY($1::int[])
    `, [[ganadorId, subcampeonId]]);

    const byId = new Map(eqRows.map(r => [r.id, r.sucursal]));
    const sucGan = byId.get(ganadorId)    || 'DESCONOCIDA';
    const sucSub = byId.get(subcampeonId) || 'DESCONOCIDA';

    await client.query(`
      INSERT INTO public.medallero (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
      VALUES
        ($1, 3, $3, $4, $5),
        ($2, 1, $3, $4, $5)
      ON CONFLICT (partido_final_id) DO NOTHING
    `, [sucGan, sucSub, P.disciplina_id, P.bracket_id, partidoId]);

    await client.query('COMMIT');

    try { io.emit('medallero:changed'); } catch {}
    return res.json({ ok: true });

  } catch (err) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error('POST /api/partidos/:id/final error:', err);
    return res.status(500).json({ error: 'Error guardando final' });
  } finally {
    client.release();
  }
});  */

// Guardar FINAL (sirve para cualquier partido: avanza ganador; si es la final, suma medallero)
 app.post('/api/partidos/:id/final', requireAuth, requireRole('admin','arbitro'), async (req, res) => {
  const client = await pool.connect();
  try {
    const partidoId = Number(req.params.id);
    const { puntaje_equipo1, puntaje_equipo2 } = req.body || {};

    // Traer el partido con todo lo necesario
    const { rows: pRows } = await client.query(`
      SELECT p.id, p.bracket_id, p.disciplina_id, p.round, p.orden,
             p.equipo1_id, p.equipo2_id,
             p.next_match_id, p.next_match_side
        FROM public.partidos p
       WHERE p.id = $1
       LIMIT 1
    `, [partidoId]);

    if (pRows.length === 0) return res.status(404).json({ error: 'Partido no encontrado' });
    const P = pRows[0];

    // Validaciones
    if (!P.equipo1_id || !P.equipo2_id) {
      return res.status(400).json({ error: 'Partido incompleto' });
    }
    const s1 = Number(puntaje_equipo1) || 0;
    const s2 = Number(puntaje_equipo2) || 0;
    if (s1 === s2) return res.status(400).json({ error: 'El partido no puede terminar empatado' });

    const ganadorId     = s1 > s2 ? P.equipo1_id : P.equipo2_id;
    const subcampeonId  = s1 > s2 ? P.equipo2_id : P.equipo1_id;

    await client.query('BEGIN');

    // 1) Guardar resultado y cerrar partido
     await client.query(`
      INSERT INTO public.resultados(partido_id, puntaje_equipo1, puntaje_equipo2, ganador_id)
      VALUES ($1, $2, $3, $4)
    `, [partidoId, s1, s2, ganadorId]); 

    


    await client.query(`UPDATE public.partidos SET estado='finalizado' WHERE id=$1`, [partidoId]);

    // 2) Avanzar ganador si hay siguiente partido
    const esFinal = (P.next_match_id === null);

    if (!esFinal) {
      // setear ganador en el lado que corresponda (1 o 2) del próximo partido
      const col = (Number(P.next_match_side) === 2) ? 'equipo2_id' : 'equipo1_id';
      await client.query(
        `UPDATE public.partidos SET ${col} = $1 WHERE id = $2`,
        [ganadorId, P.next_match_id]
      );
      // opcional: si ambos lados del siguiente partido ya están, dejarlo 'pendiente'
      await client.query(`
        UPDATE public.partidos
           SET estado = CASE
                          WHEN equipo1_id IS NOT NULL AND equipo2_id IS NOT NULL THEN 'pendiente'
                          ELSE estado
                        END
         WHERE id = $1
      `, [P.next_match_id]);

    } else {
      // 3) Es la FINAL real: sumar medallero (campeón=3, subcampeón=1)
      const { rows: eqRows } = await client.query(`
        SELECT e.id, e.sucursal
          FROM public.equipos e
         WHERE e.id = ANY($1::int[])
      `, [[ganadorId, subcampeonId]]);
      const byId = new Map(eqRows.map(r => [r.id, r.sucursal]));
      const sucGan = byId.get(ganadorId)    || 'DESCONOCIDA';
      const sucSub = byId.get(subcampeonId) || 'DESCONOCIDA';

      // Evitar dobles clics con UNIQUE(partido_final_id)
    /*   await client.query(`
        INSERT INTO public.medallero (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
        VALUES
          ($1, 3, $3, $4, $5),
          ($2, 1, $3, $4, $5)
        ON CONFLICT (partido_final_id) DO NOTHING
      `, [sucGan, sucSub, P.disciplina_id, P.bracket_id, partidoId]); */
      // 5) Insertar puntajes en medallero (campeón=3, subcampeón=1)
//    Prevenimos dobles clics con ON CONFLICT sobre (partido_final_id, sucursal)
  // Campeón = 3 pts
  await client.query(`
  INSERT INTO public.medallero
    (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
  VALUES
    ($1,       $2,     $3,            $4,        $5)
  ON CONFLICT (partido_final_id, sucursal) DO NOTHING
  `, [sucGan, 3, P.disciplina_id, P.bracket_id, partidoId]);

  // Subcampeón = 1 pto
  await client.query(`
  INSERT INTO public.medallero
    (sucursal, puntos, disciplina_id, bracket_id, partido_final_id)
  VALUES
    ($1,       $2,     $3,            $4,        $5)
  ON CONFLICT (partido_final_id, sucursal) DO NOTHING
  `, [sucSub, 1, P.disciplina_id, P.bracket_id, partidoId]);

    }

    await client.query('COMMIT');

    // 4) eventos para refrescar
    try { app.get('io')?.emit('partido_updated', { partido_id: partidoId, bracket_id: P.bracket_id }); } catch {}
    if (esFinal) {
      try { app.get('io')?.emit('medallero:changed'); } catch {}
    }

    return res.json({ ok: true, esFinal });

  } catch (err) {
    try { await client.query('ROLLBACK'); } catch {}
    console.error('POST /api/partidos/:id/final error:', err);
    return res.status(500).json({ error: 'Error guardando final' });
  } finally {
    client.release();
  }
}); 


// Medallero (agregado por sucursal)
app.get('/api/medallero', requireAuth, async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT sucursal, SUM(puntos)::int AS puntos
      FROM public.medallero
      GROUP BY sucursal
      ORDER BY SUM(puntos) DESC, sucursal ASC
    `);
    res.json(rows);
  } catch (e) {
    console.error('GET /api/medallero', e);
    res.status(500).json({ error: 'Error cargando medallero' });
  }
});

// Buscar último bracket por disciplina
// --- Último bracket por disciplina (para visor) ---
app.get('/api/brackets/byDisciplina/:disciplina_id', requireAuth, async (req, res) => {
  try {
    const did = Number(req.params.disciplina_id || 0);
    if (!did) return res.status(400).json({ error: 'disciplina_id inválido' });

    // Si no tenés created_at en brackets, ordenamos por id DESC.
    const { rows } = await pool.query(
      `SELECT id
         FROM public.brackets
        WHERE disciplina_id = $1
        ORDER BY id DESC
        LIMIT 1`,
      [did]
    );

    if (rows.length === 0) return res.status(404).json({ error: 'Sin brackets para la disciplina' });
    res.json({ bracket_id: rows[0].id });
  } catch (e) {
    console.error('GET /api/brackets/byDisciplina/:disciplina_id', e);
    res.status(500).json({ error: 'Error obteniendo bracket' });
  }
});



// Socket.IO básico
io.on('connection', () => {});

// Arranque
server.listen(PORT, () => {
  console.log(`Servidor escuchando en http://0.0.0.0:${PORT}`);
});
